
export default function Pedido() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Tu Pedido</h1>
      <p>Carrito de compras con opciones de pago SINPE o Stripe (simulado).</p>
      <button style={{ marginTop: '1rem' }}>Finalizar pedido</button>
    </div>
  )
}
