
export default function Explorar() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Explorar Comercios</h1>
      <ul>
        <li>🍔 Restaurante La Fortuna</li>
        <li>🥐 Panadería El Trigo</li>
        <li>🛍️ Súper Quesada</li>
      </ul>
    </div>
  )
}
